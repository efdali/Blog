<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 29.09.2018
 * Time: 17:45
 */

    include "connection.php";

    $yaziId=$_GET["yaziId"];
    $kullaniciId=$_GET["kullaniciId"];
    $yorum=$_GET["yorum"];

    $query=$db->prepare("INSERT INTO yorumlar SET yaziId=? , kullaniciId=? , yorumIcerik=?");

    $insert=$query->execute(array($yaziId,$kullaniciId,$yorum));

    if ($insert){
        echo json_encode(array("result"=>"ok"));
    }else{
        echo json_encode(array("result"=>"no"));
    }

?>
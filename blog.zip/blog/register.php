<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 26.09.2018
 * Time: 12:11
 */

    include "connection.php";

    $kadi = $_POST["kadi"];
    $mail = $_POST["mail"];
    $sifre = $_POST["sifre"];
    $resim = $_POST["resim"];

    $insert;

    if ($resim!=-1) {

        $part = "kullanici-resim/";
        $filename = "img" . rand(9, 9999) . ".jpg";
        $destinationfile = $part . $filename;

        $query = $db->prepare("INSERT INTO kullanici SET
        uyeResim=?,
        uyeNick = ?,
        uyeMail = ?,
        uyePass = ?");
        $insert = $query->execute(array(
            $destinationfile, $kadi, $mail, $sifre
        ));


        file_put_contents($destinationfile, base64_decode($resim));

    }else{

        $query = $db->prepare("INSERT INTO kullanici SET
        uyeNick = ?,
        uyeMail = ?,
        uyePass = ?");
        $insert = $query->execute(array(
            $kadi, $mail, $sifre
        ));


    }
    if ($insert) {
        echo json_encode(array("result" => "ok"));
    } else {
        echo json_encode(array("result" => "no"));
    }

?>
<?php

    include "connection.php";
    include "Article.php";

    $kullaniciId=$_GET['kullaniciId'];

    $query=$db->query("SELECT * from yazilar where yaziId in(select yaziId from begeniler where kullaniciId='$kullaniciId')"
    ,PDO::FETCH_ASSOC);
    $sayi=0;
    $toplam=$query->rowCount();
    echo "[";
    foreach( $query as $yazi ){
        $sayi++;
        $article=new Article($yazi["yaziId"],$yazi["yaziBaslik"],$yazi["yaziIcerik"],$yazi["yaziResim"],$yazi["yaziTarih"]);
        echo json_encode($article);
        if ($sayi!=$toplam){
            echo ",";
        }
    }
    echo "]";



?>
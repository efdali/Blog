<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 23.09.2018
 * Time: 13:41
 */

    include "connection.php";
    include "Article.php";

    $query=$db->query("select yazilar.yaziId,yaziBaslik,yaziIcerik,yaziResim,yaziTarih,COUNT(*) as yorumSayisi 
                               from yazilar left join yorumlar on yazilar.yaziId=yorumlar.yaziId 
                               GROUP by yazilar.yaziId"
        ,PDO::FETCH_ASSOC);
    $sayi=0;
    $toplam=$query->rowCount();
    echo "[";
    foreach( $query as $yazi ){
        $sayi++;
        $article=new ArticleWithComment($yazi["yaziId"],$yazi["yaziBaslik"],$yazi["yaziIcerik"],$yazi["yaziResim"],$yazi["yaziTarih"],$yazi["yorumSayisi"]);
        echo json_encode($article);
        if ($sayi!=$toplam){
            echo ",";
        }
    }
    echo "]";



?>
<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 23.09.2018
 * Time: 18:57
 */

    include "connection.php";
    include "Article.php";

    $id = $_GET["yaziId"];
    $query = $db->query("SELECT yazilar.yaziId,yaziBaslik,yaziIcerik,yaziResim,yaziTarih,yazar.yazarId,yazarNick,kategoriler.kategoriAdi,kategoriler.kategoriId,COUNT(begeniler.begeniId) as begeniSayisi
                                   FROM yazilar,yazar,kategoriler,begeniler
                                   WHERE yazilar.yazarId=yazar.yazarId AND yazilar.yaziKategori=kategoriler.kategoriId AND begeniler.yaziId=yazilar.yaziId
                                   AND yazilar.yaziId=$id")->fetch(PDO::FETCH_ASSOC);


    echo "[";
    $article = new ArticleDetails($query["yaziId"], $query["yaziBaslik"], $query["yaziIcerik"], $query["yaziResim"], $query["yaziTarih"], $query["kategoriId"], $query["kategoriAdi"], $query["yazarNick"], $query["yazarId"], $query["begeniSayisi"]);
    echo json_encode($article);
    echo "]";


?>
<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 24.09.2018
 * Time: 14:32
 */

    include "connection.php";
    include "Article.php";

    $yaziId=$_GET["yaziId"];

    $query=$db->query("Select yorumIcerik,yorumTarih,kullanici.uyeNick,kullanici.uyeResim from yorumlar ,kullanici where yorumlar.kullaniciId=kullanici.uyeId and yaziId=$yaziId",PDO::FETCH_ASSOC);

    $toplam=$query->rowCount();
    $sayi=0;
    echo "[";
    foreach ($query as $comment){

        $sayi++;
        $kullanici=new Member($comment["uyeNick"],$comment["uyeResim"]);
        $yorum=new Comment($comment["yorumIcerik"],$comment["yorumTarih"],$kullanici);
        echo json_encode($yorum);
        if ($sayi!=$toplam){
            echo ",";
        }

    }

    echo "]";

?>
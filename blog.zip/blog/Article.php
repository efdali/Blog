<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 23.09.2018
 * Time: 13:59
 */

class ArticleWithComment extends Article {
    public $yorumSayisi;

    public function __construct($yaziId,$yaziBaslik, $yaziIcerik, $yaziResim, $yaziTarih, $yorumSayisi)
    {
        parent::__construct($yaziId,$yaziBaslik,$yaziIcerik,$yaziResim,$yaziTarih);
        $this->yorumSayisi=$yorumSayisi;
    }


}

class ArticleDetails extends Article{

    public $kategoriId;
    public $kategoriAdi;
    public $yazarAdi;
    public $yazarId;
    public $begeniSayisi;

    public function __construct($yaziId,$yaziBaslik, $yaziIcerik, $yaziResim, $yaziTarih,$kategoriId,$kategoriAdi,$yazarAdi,$yazarId,$begeniSayisi)
    {
        parent::__construct($yaziId,$yaziBaslik,$yaziIcerik,$yaziResim,$yaziTarih);
        $this->kategoriAdi = $kategoriAdi;
        $this->yazarAdi=$yazarAdi;
        $this->yazarId=$yazarId;
        $this->kategoriId=$kategoriId;
        $this->begeniSayisi=$begeniSayisi;
    }


}

class Article{

    public $yaziId;
    public $yaziBaslik;
    public $yaziIcerik;
    public $yaziResim;
    public $yaziTarih;

    public function __construct($yaziId,$yaziBaslik, $yaziIcerik, $yaziResim, $yaziTarih)
    {
        $this->yaziId=$yaziId;
        $this->yaziBaslik = $yaziBaslik;
        $this->yaziIcerik = $yaziIcerik;
        $this->yaziResim = $yaziResim;
        $this->yaziTarih = $yaziTarih;
    }


}

class Comment{

    public $yorumIcerik;
    public $yorumTarih;
    public $kullanici;

    public function __construct($yorumIcerik, $yorumTarih, $kullanici)
    {
        $this->yorumIcerik = $yorumIcerik;
        $this->yorumTarih = $yorumTarih;
        $this->kullanici = $kullanici;
    }


}
class Member{

    public $uyeNick;
    public $uyeResim;

    public function __construct($kullaniciNick, $kullaniciResim)
    {
        $this->uyeNick = $kullaniciNick;
        $this->uyeResim = $kullaniciResim;
    }


}

class User extends Member{

    public $uyeId;
    public $uyeMail;
    public $uyeSifre;

    public function __construct($uyeId,$uyeNick, $uyeMail,$uyeResim,$uyeSifre)
    {
        parent::__construct($uyeNick,$uyeResim);
        $this->uyeId = $uyeId;
        $this->uyeMail = $uyeMail;
        $this->uyeSifre=$uyeSifre;
    }


}

class Author{

    public $yazarNick;
    public $yazarPuan;
    public $yazarResim;
    public $yazBasTarih;
    public $yazilar;

    public function __construct($yazarNick, $yazarResim, $yazarPuan, $yazBasTarih,$yazilar)
    {
        $this->yazarNick = $yazarNick;
        $this->yazarPuan = $yazarPuan;
        $this->yazarResim = $yazarResim;
        $this->yazBasTarih = $yazBasTarih;
        $this->yazilar=$yazilar;
    }


}

?>
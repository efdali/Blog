<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 28.09.2018
 * Time: 20:18
 */


    include "connection.php";
    include "Article.php";

    $uyeNick=$_POST["kadi"];
    $uyePass=$_POST["sifre"];

    $user;
    $query=$db->query("select * from kullanici where uyeNick='$uyeNick' and uyePass='$uyePass' and uyeDurum=1 ",PDO::FETCH_ASSOC);

    if ($query->rowCount()==1){
        foreach ($query as $row){
            $user=new User($row["uyeId"],$row["uyeNick"],$row["uyeMail"],$row["uyeResim"],$row["uyePass"]);
        }
        echo json_encode($user);
    }else{
        $user=new User("-1","-1","-1","-1","-1");
        echo json_encode($user);
    }

?>
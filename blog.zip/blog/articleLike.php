<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 29.09.2018
 * Time: 16:55
 */

    include "connection.php";

    $yaziId=$_GET["yaziId"];
    $kullaniciId=$_GET["kullaniciId"];
    $durum=$_GET["durum"];

    $insert;

    if ($durum=="true"){
        $query=$db->prepare("insert into begeniler set yaziId =?,kullaniciId=?");
        $insert=$query->execute(array($yaziId,$kullaniciId));

    }else{

        $query=$db->prepare("delete from begeniler where yaziId=? and kullaniciId=?");
        $insert=$query->execute(array($yaziId,$kullaniciId));

    }

    if ($insert){
        echo json_encode(array("result"=>$durum));
    }else{
        echo json_encode(array("result"=>"no"));
    }

?>
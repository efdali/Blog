<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 24.09.2018
 * Time: 22:57
 */

    include "connection.php";


    $query=$db->query("Select * from kategoriler",PDO::FETCH_ASSOC);
    $toplam=$query->rowCount();
    $sayi=0;
    echo "[";
    foreach ($query as $row){
        $sayi++;
        $kategori=new Category($row["kategoriId"],$row["kategoriAdi"],$row["kategoriResmi"]);
        echo json_encode($kategori);

        if ($sayi!=$toplam){
            echo ",";
        }
    }
    echo "]";

class Category{

    public $kategoriId;
    public $kategoriAdi;
    public $kategoriResmi;


    public function __construct($kategoriId, $kategoriAdi, $kategoriResmi)
    {
        $this->kategoriId = $kategoriId;
        $this->kategoriAdi = $kategoriAdi;
        $this->kategoriResmi = $kategoriResmi;
    }


}
?>
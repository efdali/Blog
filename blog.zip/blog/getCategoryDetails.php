<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 25.09.2018
 * Time: 12:55
 */

    include "connection.php";
    include "Article.php";

    $kategoriId=$_GET["kategoriId"];

    $query=$db->query("select yazilar.yaziId,yaziBaslik,yaziIcerik,yaziResim,yaziTarih,COUNT(*) as yorumSayisi 
                               from yazilar left join yorumlar on yazilar.yaziId=yorumlar.yaziId where yazilar.yaziKategori=$kategoriId GROUP by yazilar.yaziId",PDO::FETCH_ASSOC);
    $toplam=$query->rowCount();
    $sayi=0;
    echo "[";
    foreach ($query as $row){
        $sayi++;

        $article=new ArticleWithComment($row["yaziId"],$row["yaziBaslik"],$row["yaziIcerik"],$row["yaziResim"],$row["yaziTarih"],$row["yorumSayisi"]);
        echo json_encode($article);
        if ($sayi!=$toplam){
            echo ",";
        }

    }
    echo "]";


?>
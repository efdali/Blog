<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 29.09.2018
 * Time: 11:54
 */


    include "connection.php";
    include "Article.php";

    $uyeId=$_POST["id"];
    $kadi = $_POST["kadi"];
    $mail = $_POST["mail"];
    $sifre = $_POST["sifre"];
    $resim = $_POST["resim"];

    $queryResim=$db->query("select uyeResim from kullanici where uyeId=$uyeId ")->fetch(PDO::FETCH_ASSOC);
    $insert;

    $root=$_SERVER['DOCUMENT_ROOT'];
    if ($resim!=-1) {

        $part = "kullanici-resim/";
        $filename = "img" . rand(9, 9999) . ".jpg";
        $destinationfile = $part . $filename;

        unlink($root."/blog/".$queryResim["uyeResim"]);
        $insert=$db->query("update kullanici 
                                    set uyeNick= '{$kadi}' ,uyePass = '{$sifre}',uyeMail='{$mail}',uyeResim='{$destinationfile}' 
                                    where uyeId='{$uyeId}'");

        file_put_contents($destinationfile, base64_decode($resim));

    }else{

        $insert=$db->query("update kullanici 
                                    set uyeNick= '{$kadi}' ,uyePass = '{$sifre}',uyeMail='{$mail}' 
                                    where uyeId='{$uyeId}'");


    }

    if ($insert){

        echo json_encode(array("result" => "ok"));
    }else{
        echo json_encode(array("resutl" => "no"));
    }



?>
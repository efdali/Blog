<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 22.09.2018
 * Time: 23:00
 */

    $host="sql168.main-hosting.eu";
    $kadi="u426356562_root";
    $sifre="efdal1234567890";
    $databaseName="u426356562_blog";

    try {
        $db = new PDO("mysql:host=$host;dbname=$databaseName;charset=utf8", $kadi, $sifre);
    }catch (PDOException $e){
    }

?>
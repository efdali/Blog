<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 24.09.2018
 * Time: 12:39
 */

    include "connection.php";
    include "Article.php";

    $yazarId=$_GET["yazarId"];
    $query=$db->query("select yazarNick,yazarResim,yazarPuan,yazarBasTarih,y.yaziId,y.yaziBaslik,y.yaziIcerik,y.yaziResim,y.yaziTarih from yazar a,yazilar y where y.yazarId=a.yazarId and a.yazarId=$yazarId",PDO::FETCH_ASSOC);
    $toplam=$query->rowCount();;
    $sayi=0;
    $articleDizi=array();

    $queryPuan=$db->query("select count(*)* 10 as yazarPuan from begeniler where yaziId in (select yaziId from yazilar where yazarId=$yazarId)")->fetch(PDO::FETCH_ASSOC);

    foreach ($query as $row){

        $article=new Article($row["yaziId"],$row["yaziBaslik"],$row["yaziIcerik"],$row["yaziResim"],$row["yaziTarih"]);
        array_push($articleDizi,$article);
        $sayi++;

        if ($sayi==$toplam){

            $yazar=new Author($row["yazarNick"], $row["yazarResim"],$queryPuan["yazarPuan"],$row["yazarBasTarih"],$articleDizi);
            echo json_encode($yazar);
        }


    }






?>
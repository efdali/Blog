<?php
/**
 * Created by PhpStorm.
 * User: Efdal Incesu
 * Date: 29.09.2018
 * Time: 16:25
 */

    include "connection.php";

    $id=$_GET["yaziId"];
    $kid=$_GET["kullaniciId"];

    $query=$db->query("select * from begeniler where yaziId='{$id}' and kullaniciId='{$kid}'")->fetch(PDO::FETCH_ASSOC);

    if ($query){
        echo json_encode(array("result" => "ok"));
    }else{
        echo json_encode(array("result" => "no"));
    }

?>
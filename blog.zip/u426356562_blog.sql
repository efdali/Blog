-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 16 Kas 2018, 13:14:23
-- Sunucu sürümü: 10.2.17-MariaDB
-- PHP Sürümü: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `u426356562_blog`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `begeniler`
--

CREATE TABLE `begeniler` (
  `begeniId` int(11) NOT NULL,
  `kullaniciId` int(11) NOT NULL,
  `yaziId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `begeniler`
--

INSERT INTO `begeniler` (`begeniId`, `kullaniciId`, `yaziId`) VALUES
(1, 1, 2),
(2, 1, 3),
(4, 2, 2),
(5, 5, 3),
(6, 5, 5),
(7, 5, 4),
(8, 5, 2),
(9, 2, 3),
(10, 2, 5);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kategoriler`
--

CREATE TABLE `kategoriler` (
  `kategoriId` int(11) NOT NULL,
  `kategoriAdi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kategoriResmi` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `kategoriler`
--

INSERT INTO `kategoriler` (`kategoriId`, `kategoriAdi`, `kategoriResmi`) VALUES
(1, 'Yazılım', 'https://cdn0.iconfinder.com/data/icons/kameleon-free-pack-rounded/110/Coding-Html-512.png'),
(2, 'Siyaset', 'https://cdn0.iconfinder.com/data/icons/kameleon-free-pack-rounded/110/Coding-Html-512.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

CREATE TABLE `kullanici` (
  `uyeId` int(11) NOT NULL,
  `uyeNick` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uyeMail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uyePass` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `uyeResim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uyeKayitTarihi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `uyeDurum` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`uyeId`, `uyeNick`, `uyeMail`, `uyePass`, `uyeResim`, `uyeKayitTarihi`, `uyeDurum`) VALUES
(1, 'efdali', 'efdal_incesu@hotmail.com', 'efdal1234567890', 'kullanici-resim/img9136.jpg', '2018-09-29 17:53:03', 1),
(2, 'efdalink1', 'efdalink@gmail.com', 'efdalink1', 'kullanici-resim/img1518.jpg', '2018-10-01 09:32:04', 1),
(3, 'reis', 'reis@gmail', 'reis123', 'kullanici-resim/img1244.jpg', '2018-10-01 10:10:22', 1),
(4, 'sonkayit', 'sonkayit@gmail', 'okeyy1w3', 'kullanici-resim/img5327.jpg', '2018-10-01 10:48:45', 1),
(5, 'reis123', 'reis123@gmail.com', 'reis123', 'kullanici-resim/img4672.jpg', '2018-10-02 10:32:18', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yazar`
--

CREATE TABLE `yazar` (
  `yazarId` int(11) NOT NULL,
  `yazarNick` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `yazarPass` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `yazarResim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `yazarPuan` int(11) NOT NULL DEFAULT 0,
  `yazarBasTarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `yazar`
--

INSERT INTO `yazar` (`yazarId`, `yazarNick`, `yazarPass`, `yazarResim`, `yazarPuan`, `yazarBasTarih`) VALUES
(2, 'efdali', 'efdal1234567890', 'kullanici-resim/anonymous-user.png', 0, '2018-10-29 07:25:34'),
(3, 'punis', 'punis', 'kullanici-resim/anonymous-user.png', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yazilar`
--

CREATE TABLE `yazilar` (
  `yaziId` int(11) NOT NULL,
  `yaziBaslik` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `yaziIcerik` text COLLATE utf8_unicode_ci NOT NULL,
  `yaziResim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `yazarId` int(11) NOT NULL,
  `yaziKategori` int(11) NOT NULL,
  `yaziTarih` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `yazilar`
--

INSERT INTO `yazilar` (`yaziId`, `yaziBaslik`, `yaziIcerik`, `yaziResim`, `yazarId`, `yaziKategori`, `yaziTarih`) VALUES
(2, 'Yazı Baslik 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam convallis tincidunt arcu eget lacinia. Donec sodales sed lorem et elementum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed varius elementum nisl nec imperdiet. Pellentesque vel sem dictum, mollis nunc eget, pharetra sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean lorem nibh, aliquam id metus vitae, ultrices porttitor magna. Aliquam a lectus sollicitudin lectus feugiat placerat sit amet eu orci. Praesent cursus, leo ut venenatis pulvinar, magna est vestibulum nisl, quis vulputate nunc sem a lectus. Sed varius ut dolor et dignissim. Aenean bibendum velit metus, eget fermentum nibh tempus cursus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut leo lacus, varius eget lobortis quis, mollis sit amet ligula. Mauris consequat, massa sed aliquet dignissim, nisi ante consectetur nisi, eget placerat sapien est vitae leo. Fusce id fermentum ex.\r\n\r\nMauris hendrerit sed arcu eget dapibus. Nunc nec maximus turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum venenatis cursus velit et imperdiet. Donec luctus blandit ipsum, nec consequat justo consequat eget. Aenean imperdiet porta tincidunt. Praesent efficitur quam ligula, tristique aliquam ligula vehicula ac. Aenean eleifend a sem et maximus. Nam tempus pulvinar nisi, eu sodales lectus consectetur at. Duis ligula dui, faucibus et congue non, interdum quis mi.', 'https://productimages.hepsiburada.net/s/7/200/9771544313906.jpg', 2, 1, '2018-09-29 20:30:00'),
(3, 'Yazı Baslik 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam convallis tincidunt arcu eget lacinia. Donec sodales sed lorem et elementum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed varius elementum nisl nec imperdiet. Pellentesque vel sem dictum, mollis nunc eget, pharetra sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean lorem nibh, aliquam id metus vitae, ultrices porttitor magna. Aliquam a lectus sollicitudin lectus feugiat placerat sit amet eu orci. Praesent cursus, leo ut venenatis pulvinar, magna est vestibulum nisl, quis vulputate nunc sem a lectus. Sed varius ut dolor et dignissim. Aenean bibendum velit metus, eget fermentum nibh tempus cursus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut leo lacus, varius eget lobortis quis, mollis sit amet ligula. Mauris consequat, massa sed aliquet dignissim, nisi ante consectetur nisi, eget placerat sapien est vitae leo. Fusce id fermentum ex.\r\n\r\nMauris hendrerit sed arcu eget dapibus. Nunc nec maximus turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum venenatis cursus velit et imperdiet. Donec luctus blandit ipsum, nec consequat justo consequat eget. Aenean imperdiet porta tincidunt. Praesent efficitur quam ligula, tristique aliquam ligula vehicula ac. Aenean eleifend a sem et maximus. Nam tempus pulvinar nisi, eu sodales lectus consectetur at. Duis ligula dui, faucibus et congue non, interdum quis mi.', 'https://productimages.hepsiburada.net/s/7/200/9771544313906.jpg', 2, 1, '2018-09-29 20:30:00'),
(4, 'Yazı Baslik 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam convallis tincidunt arcu eget lacinia. Donec sodales sed lorem et elementum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed varius elementum nisl nec imperdiet. Pellentesque vel sem dictum, mollis nunc eget, pharetra sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean lorem nibh, aliquam id metus vitae, ultrices porttitor magna. Aliquam a lectus sollicitudin lectus feugiat placerat sit amet eu orci. Praesent cursus, leo ut venenatis pulvinar, magna est vestibulum nisl, quis vulputate nunc sem a lectus. Sed varius ut dolor et dignissim. Aenean bibendum velit metus, eget fermentum nibh tempus cursus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut leo lacus, varius eget lobortis quis, mollis sit amet ligula. Mauris consequat, massa sed aliquet dignissim, nisi ante consectetur nisi, eget placerat sapien est vitae leo. Fusce id fermentum ex.\r\n\r\nMauris hendrerit sed arcu eget dapibus. Nunc nec maximus turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum venenatis cursus velit et imperdiet. Donec luctus blandit ipsum, nec consequat justo consequat eget. Aenean imperdiet porta tincidunt. Praesent efficitur quam ligula, tristique aliquam ligula vehicula ac. Aenean eleifend a sem et maximus. Nam tempus pulvinar nisi, eu sodales lectus consectetur at. Duis ligula dui, faucibus et congue non, interdum quis mi.', 'https://productimages.hepsiburada.net/s/7/200/9771544313906.jpg', 2, 1, '2018-09-29 20:30:00'),
(5, 'Yazı 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam convallis tincidunt arcu eget lacinia. Donec sodales sed lorem et elementum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed varius elementum nisl nec imperdiet. Pellentesque vel sem dictum, mollis nunc eget, pharetra sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean lorem nibh, aliquam id metus vitae, ultrices porttitor magna. Aliquam a lectus sollicitudin lectus feugiat placerat sit amet eu orci. Praesent cursus, leo ut venenatis pulvinar, magna est vestibulum nisl, quis vulputate nunc sem a lectus. Sed varius ut dolor et dignissim. Aenean bibendum velit metus, eget fermentum nibh tempus cursus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut leo lacus, varius eget lobortis quis, mollis sit amet ligula. Mauris consequat, massa sed aliquet dignissim, nisi ante consectetur nisi, eget placerat sapien est vitae leo. Fusce id fermentum ex.\r\n\r\nMauris hendrerit sed arcu eget dapibus. Nunc nec maximus turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum venenatis cursus velit et imperdiet. Donec luctus blandit ipsum, nec consequat justo consequat eget. Aenean imperdiet porta tincidunt. Praesent efficitur quam ligula, tristique aliquam ligula vehicula ac. Aenean eleifend a sem et maximus. Nam tempus pulvinar nisi, eu sodales lectus consectetur at. Duis ligula dui, faucibus et congue non, interdum quis mi.', 'https://productimages.hepsiburada.net/s/7/200/9771544313906.jpg', 2, 1, '2018-09-29 20:30:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorumCevap`
--

CREATE TABLE `yorumCevap` (
  `cevapId` int(11) NOT NULL,
  `kullaniciId` int(11) NOT NULL,
  `yorumId` int(11) NOT NULL,
  `cevapIcerik` text COLLATE utf8_unicode_ci NOT NULL,
  `cevapTarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorumlar`
--

CREATE TABLE `yorumlar` (
  `yorumId` int(11) NOT NULL,
  `kullaniciId` int(11) NOT NULL,
  `yaziId` int(11) NOT NULL,
  `yorumIcerik` text COLLATE utf8_unicode_ci NOT NULL,
  `yorumTarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `yorumlar`
--

INSERT INTO `yorumlar` (`yorumId`, `kullaniciId`, `yaziId`, `yorumIcerik`, `yorumTarih`) VALUES
(1, 1, 2, 'Çok Mantıklı Güzel Yazı', '2018-09-29 12:30:40'),
(2, 1, 2, 'Yorum 2', '2018-09-29 12:30:40'),
(3, 1, 3, 'reis ne guzel anlatmissi oyle xd', '2018-09-29 17:42:22'),
(4, 2, 3, 'vayy be', '2018-10-01 09:36:55'),
(5, 2, 3, 'okeyyy', '2018-10-01 09:38:13'),
(6, 2, 2, 'okeyyy', '2018-10-01 09:38:29'),
(7, 2, 3, 'okeyyy', '2018-10-01 11:31:22'),
(8, 2, 3, 'ok', '2018-10-01 11:38:36'),
(9, 5, 3, 'reis güzel', '2018-10-02 10:31:39'),
(10, 5, 5, 'selam', '2018-10-02 14:10:37');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `begeniler`
--
ALTER TABLE `begeniler`
  ADD PRIMARY KEY (`begeniId`),
  ADD KEY `Begeniler_fk0` (`kullaniciId`),
  ADD KEY `Begeniler_fk1` (`yaziId`);

--
-- Tablo için indeksler `kategoriler`
--
ALTER TABLE `kategoriler`
  ADD PRIMARY KEY (`kategoriId`);

--
-- Tablo için indeksler `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`uyeId`),
  ADD UNIQUE KEY `uyeNick` (`uyeNick`),
  ADD UNIQUE KEY `uyeMail` (`uyeMail`);

--
-- Tablo için indeksler `yazar`
--
ALTER TABLE `yazar`
  ADD PRIMARY KEY (`yazarId`),
  ADD UNIQUE KEY `yazarNick` (`yazarNick`);

--
-- Tablo için indeksler `yazilar`
--
ALTER TABLE `yazilar`
  ADD PRIMARY KEY (`yaziId`),
  ADD KEY `Yazilar_fk0` (`yazarId`),
  ADD KEY `Yazilar_fk1` (`yaziKategori`);

--
-- Tablo için indeksler `yorumCevap`
--
ALTER TABLE `yorumCevap`
  ADD PRIMARY KEY (`cevapId`),
  ADD KEY `YorumCevap_fk0` (`kullaniciId`),
  ADD KEY `YorumCevap_fk1` (`yorumId`);

--
-- Tablo için indeksler `yorumlar`
--
ALTER TABLE `yorumlar`
  ADD PRIMARY KEY (`yorumId`),
  ADD KEY `Yorumlar_fk0` (`kullaniciId`),
  ADD KEY `Yorumlar_fk1` (`yaziId`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `begeniler`
--
ALTER TABLE `begeniler`
  MODIFY `begeniId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Tablo için AUTO_INCREMENT değeri `kategoriler`
--
ALTER TABLE `kategoriler`
  MODIFY `kategoriId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `uyeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `yazar`
--
ALTER TABLE `yazar`
  MODIFY `yazarId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `yazilar`
--
ALTER TABLE `yazilar`
  MODIFY `yaziId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `yorumCevap`
--
ALTER TABLE `yorumCevap`
  MODIFY `cevapId` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `yorumlar`
--
ALTER TABLE `yorumlar`
  MODIFY `yorumId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `begeniler`
--
ALTER TABLE `begeniler`
  ADD CONSTRAINT `Begeniler_fk0` FOREIGN KEY (`kullaniciId`) REFERENCES `kullanici` (`uyeId`),
  ADD CONSTRAINT `Begeniler_fk1` FOREIGN KEY (`yaziId`) REFERENCES `yazilar` (`yaziId`);

--
-- Tablo kısıtlamaları `yazilar`
--
ALTER TABLE `yazilar`
  ADD CONSTRAINT `Yazilar_fk0` FOREIGN KEY (`yazarId`) REFERENCES `yazar` (`yazarId`),
  ADD CONSTRAINT `Yazilar_fk1` FOREIGN KEY (`yaziKategori`) REFERENCES `kategoriler` (`kategoriId`);

--
-- Tablo kısıtlamaları `yorumCevap`
--
ALTER TABLE `yorumCevap`
  ADD CONSTRAINT `YorumCevap_fk0` FOREIGN KEY (`kullaniciId`) REFERENCES `kullanici` (`uyeId`),
  ADD CONSTRAINT `YorumCevap_fk1` FOREIGN KEY (`yorumId`) REFERENCES `yorumlar` (`yorumId`);

--
-- Tablo kısıtlamaları `yorumlar`
--
ALTER TABLE `yorumlar`
  ADD CONSTRAINT `Yorumlar_fk0` FOREIGN KEY (`kullaniciId`) REFERENCES `kullanici` (`uyeId`),
  ADD CONSTRAINT `Yorumlar_fk1` FOREIGN KEY (`yaziId`) REFERENCES `yazilar` (`yaziId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
